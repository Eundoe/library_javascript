/**  바코드 생성하는 함수
@param {string} elementId 해당 데이터를 출력할 태그
@param {string} value 변환할 값
@return {boolean} 생성 성공여부  true/false
@version 0.0.1 2025.07.23
*/
function generateBarcode(elementId, value) {
  const el = document.querySelector(elementId);
  const APPRV_EL_LIST = ['IMG', 'SVG', 'CANVAS'];
  if (!el) {
    window.alert('생성할 객체대상이없습니다.');
    return false;
  } else if (!APPRV_EL_LIST.includes(el.tagName)) {
    window.alert(
      '유효한 객체가아닙니다.\n바코드는 img, svg, canvas에서만 생성가능합니다.'
    );
    return false;
  }
  //바코드 생성기
  JsBarcode(elementId, value, {
    format: 'CODE128', //고정 CODE128B 대문자, 소문자, 숫자까지만 입력가능
    width: 2, //바코드개당 너비
    height: 40, //바코드 개당 높이,
    lineColor: '#000', //바코드개당 색상 HEX코드로만 작성
    displayValue: true, //해당 바코드의 값보여주기,
    background: 'transparent', //백그라운드 색상설정
    text: undefined, //displayValue대신 보여주게하는값 undefined시에는value값 보여줌
  });
  return true;
}

/**  쿠폰생성용 함수 고정값으로 대분류/중분류/앞번호 까지는 받아오 그뒤은 4자릿수 자동생성
@param {string|number} bigCategory 대분류
@param {string|number} middleCategory 중분류
@param {string|number} frontNumber 앞번호
@version 0.0.1 2025.07.23
@return {string} 반환되는 쿠폰값
*/
function generateCoupons(bigCategory, middleCategory, frontNumber) {
  if (!bigCategory || String(bigCategory).replace(/\s/g, '') === '') {
    window.alert('대분류가 설정되지않았습니다.');
    return null;
  } else if (
    !middleCategory ||
    String(middleCategory).replace(/\s/g, '') === ''
  ) {
    window.alert('중분류가 설정되지않았습니다.');
    return null;
  } else if (!frontNumber || String(frontNumber).replace(/\s/g, '') === '') {
    window.alert('구분숫자 설정되지않았습니다.');
    return null;
  }

  return `${bigCategory}${middleCategory}${frontNumber}${
    Math.floor(Math.random() * 9000) + 1000
  }${Math.floor(Math.random() * 9000) + 1000}`;
}

/** 바코드 받은감 해체분석용 
@param {string}  barcodeValue 바코드 읽어온값
@version 0.0.1 2025.07.23
@return {object} 바코드 반환한값
*/
function dissectionBarcodeValue(barcodeValue) {
  //현재 마스타 상태에서 키, 인덱스 , 길이 설정된상태 포맷변경에 따라 변경가능
  if (!barcodeValue || barcodeValue.replace(/\s/g, '') === '') {
    window.alert('분석할 바코드값이 없습니다.');
    return null;
  }

  const COUPON_FORMAT = [
    { key: 'bigCategory', index: 0, length: 1 },
    { key: 'middleCategory', index: 1, length: 1 },
    { key: 'frontNumber', index: 2, length: 2 },
    { key: 'random4-1', index: 4, length: 4 },
    { key: 'random4-2', index: 8, length: 4 },
  ];
  let response = {};

  for (let atrb of COUPON_FORMAT) {
    response[atrb.key] = barcodeValue.slice(
      atrb.index,
      atrb.index + atrb.length
    );
  }
  return response;
}

//jquery임포트안해서 vanilla로 작성
//바코드 생성기
document
  .querySelector('button#generate-barcode-button')
  .addEventListener('click', () => {
    const couponValue = document.querySelector('input#coupon-dummy').value;
    if (!couponValue || couponValue.replace(/\s/g, '') === '') {
      window.alert('쿠폰을 먼저 생성해주세요');
      return false;
    }
    generateBarcode('#barcode-dummy', couponValue);
  });

//쿠폰 생성기(랜덤)
document
  .querySelector('button#generate-coupon-button')
  .addEventListener('click', () => {
    const coupon = generateCoupons(
      'C',
      'A',
      String(new Date().getFullYear()).slice(-2)
    );
    document.querySelector('input#coupon-dummy').value = coupon;
  });

//바코드 정보 해체기
document
  .querySelector('button#disesection-barcode-button')
  .addEventListener('click', () => {
    const couponValue = document.querySelector('input#coupon-dummy').value;
    const value = dissectionBarcodeValue(couponValue);
    console.log(value);
    document.querySelector('#disesection-barcode-info').textContent =
      JSON.stringify(value);
  });
